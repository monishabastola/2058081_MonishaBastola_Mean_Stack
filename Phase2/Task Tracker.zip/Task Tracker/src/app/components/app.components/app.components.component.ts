import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-app.components',
  templateUrl: './app.components.component.html',
  styleUrls: ['./app.components.component.css']
})
export class App.ComponentsComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
